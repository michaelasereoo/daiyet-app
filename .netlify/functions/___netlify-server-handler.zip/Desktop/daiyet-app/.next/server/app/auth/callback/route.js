var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/callback/route.js")
R.c("server/chunks/[root-of-the-server]__4f85ef69._.js")
R.c("server/chunks/5f784_2c9d13f5._.js")
R.c("server/chunks/[root-of-the-server]__4e6ad982._.js")
R.c("server/chunks/3d860_daiyet-app__next-internal_server_app_auth_callback_route_actions_0f124dde.js")
R.m(75502)
module.exports=R.m(75502).exports
