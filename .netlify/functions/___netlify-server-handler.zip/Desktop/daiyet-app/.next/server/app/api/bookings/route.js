var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/bookings/route.js")
R.c("server/chunks/[root-of-the-server]__2a297bbb._.js")
R.c("server/chunks/5f784_2c9d13f5._.js")
R.c("server/chunks/[root-of-the-server]__4e6ad982._.js")
R.c("server/chunks/Desktop_daiyet-app__next-internal_server_app_api_bookings_route_actions_87ec0581.js")
R.m(7630)
module.exports=R.m(7630).exports
