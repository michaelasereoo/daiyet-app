var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/paystack/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__1a51c599._.js")
R.c("server/chunks/[root-of-the-server]__4e6ad982._.js")
R.c("server/chunks/[root-of-the-server]__0144b8dd._.js")
R.c("server/chunks/5f784_2c9d13f5._.js")
R.c("server/chunks/c8c5a__next-internal_server_app_api_paystack_webhook_route_actions_2514c53f.js")
R.m(21282)
module.exports=R.m(21282).exports
