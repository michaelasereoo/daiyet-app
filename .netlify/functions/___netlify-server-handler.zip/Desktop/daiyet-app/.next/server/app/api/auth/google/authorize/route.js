var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/google/authorize/route.js")
R.c("server/chunks/[root-of-the-server]__9df25065._.js")
R.c("server/chunks/[root-of-the-server]__4e6ad982._.js")
R.c("server/chunks/[root-of-the-server]__0144b8dd._.js")
R.c("server/chunks/5f784_2c9d13f5._.js")
R.c("server/chunks/c8c5a__next-internal_server_app_api_auth_google_authorize_route_actions_caf8ce2b.js")
R.m(22871)
module.exports=R.m(22871).exports
