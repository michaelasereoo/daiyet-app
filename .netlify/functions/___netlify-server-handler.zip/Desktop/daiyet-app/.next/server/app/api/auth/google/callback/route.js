var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/google/callback/route.js")
R.c("server/chunks/[root-of-the-server]__7b656931._.js")
R.c("server/chunks/[root-of-the-server]__4e6ad982._.js")
R.c("server/chunks/[root-of-the-server]__0144b8dd._.js")
R.c("server/chunks/5f784_2c9d13f5._.js")
R.c("server/chunks/c8c5a__next-internal_server_app_api_auth_google_callback_route_actions_139c5f80.js")
R.m(17880)
module.exports=R.m(17880).exports
