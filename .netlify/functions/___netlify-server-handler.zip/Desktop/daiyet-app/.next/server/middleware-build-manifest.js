globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/14ccd0f017e60fe4.js",
    "static/chunks/3bb5b7e0152c5fb3.js",
    "static/chunks/b797cb8ee2414ea5.js",
    "static/chunks/17c6f31961695e8b.js",
    "static/chunks/cebe948fdd365fe0.js",
    "static/chunks/turbopack-672bcd457074fbb9.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];