globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/9130d0a29a2412bc.js",
    "static/chunks/3bb5b7e0152c5fb3.js",
    "static/chunks/61826ccc62914369.js",
    "static/chunks/03003e0f1495fcdd.js",
    "static/chunks/e481f225e705d10b.js",
    "static/chunks/turbopack-a3fcef8d26d34080.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];