module.exports=[93431,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_admin_users_page_actions_255fa677.js.map