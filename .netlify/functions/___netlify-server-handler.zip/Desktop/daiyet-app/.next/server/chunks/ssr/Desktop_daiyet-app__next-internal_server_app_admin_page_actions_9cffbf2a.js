module.exports=[63141,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_admin_page_actions_9cffbf2a.js.map