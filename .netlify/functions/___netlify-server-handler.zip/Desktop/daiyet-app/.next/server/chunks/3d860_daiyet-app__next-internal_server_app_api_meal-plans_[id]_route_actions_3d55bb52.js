module.exports=[88210,(e,o,d)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_api_meal-plans_%5Bid%5D_route_actions_3d55bb52.js.map