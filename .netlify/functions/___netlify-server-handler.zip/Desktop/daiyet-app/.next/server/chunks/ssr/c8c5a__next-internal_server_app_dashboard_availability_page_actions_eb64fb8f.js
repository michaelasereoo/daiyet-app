module.exports=[22010,(a,b,c)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_dashboard_availability_page_actions_eb64fb8f.js.map