module.exports=[19155,(a,b,c)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_dashboard_event-types_page_actions_d7d76608.js.map