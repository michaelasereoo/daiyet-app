module.exports=[45950,(e,o,d)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_api_fix-user_route_actions_b848f170.js.map