module.exports=[27126,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_paystack_callback_route_actions_16c84df6.js.map