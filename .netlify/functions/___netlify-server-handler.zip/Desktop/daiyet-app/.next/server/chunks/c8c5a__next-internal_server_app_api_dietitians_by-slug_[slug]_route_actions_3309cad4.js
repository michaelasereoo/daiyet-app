module.exports=[70458,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_dietitians_by-slug_%5Bslug%5D_route_actions_3309cad4.js.map