module.exports=[17768,(e,o,d)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_api_dashboard_stats_route_actions_b10e2f91.js.map