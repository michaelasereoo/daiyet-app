module.exports=[48973,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_user_dietitian_%5Bid%5D_route_actions_45e83dbd.js.map