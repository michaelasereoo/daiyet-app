module.exports=[40900,(a,b,c)=>{}];

//# sourceMappingURL=3a061_next-internal_server_app_dashboard_settings_notifications_page_actions_30941d2c.js.map