module.exports=[9364,(a,b,c)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_dashboard_settings_general_page_actions_ef058b3d.js.map