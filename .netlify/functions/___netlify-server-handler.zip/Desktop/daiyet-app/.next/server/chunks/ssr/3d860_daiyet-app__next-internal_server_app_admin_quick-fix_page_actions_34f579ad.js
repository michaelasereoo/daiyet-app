module.exports=[78462,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_admin_quick-fix_page_actions_34f579ad.js.map