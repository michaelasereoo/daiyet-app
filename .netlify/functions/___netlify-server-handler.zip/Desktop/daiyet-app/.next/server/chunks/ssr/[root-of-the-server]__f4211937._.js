module.exports=[93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},11535,a=>{a.n(a.i(40160))},68807,a=>{a.n(a.i(48553))},76749,a=>{a.n(a.i(29022))},26155,a=>{a.n(a.i(71633))},78158,a=>{a.n(a.i(14205))},48567,a=>{a.n(a.i(9869))},28933,a=>{a.n(a.i(81920))},75396,a=>{"use strict";let b=(0,a.i(32767).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/Desktop/daiyet-app/app/dashboard/bookings/BookingsPageClient.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/Desktop/daiyet-app/app/dashboard/bookings/BookingsPageClient.tsx <module evaluation>","default");a.s(["default",0,b])},97114,a=>{"use strict";let b=(0,a.i(32767).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/Desktop/daiyet-app/app/dashboard/bookings/BookingsPageClient.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/Desktop/daiyet-app/app/dashboard/bookings/BookingsPageClient.tsx","default");a.s(["default",0,b])},66501,a=>{"use strict";a.i(75396);var b=a.i(97114);a.n(b)},60679,a=>{"use strict";var b=a.i(11733);a.i(68636);var c=a.i(35730),d=a.i(52532),e=a.i(96859),f=a.i(66501);async function g(){try{let a=await (0,d.createClient)(),{data:{user:g},error:h}=await a.auth.getUser();(h||!g)&&(console.error("Past Bookings: No user found",{error:h?.message,hasUser:!!g,timestamp:new Date().toISOString()}),(0,c.redirect)("/dietitian-login?redirect=/dashboard/bookings/past"));let i=(0,e.createAdminClientServer)(),{data:j,error:k}=await i.from("users").select("id, role, account_status").eq("id",g.id).single();(k||!j)&&(console.error("Past Bookings: User not found in database",{error:k?.message,userId:g.id,timestamp:new Date().toISOString()}),(0,c.redirect)("/dietitian-enrollment")),"DIETITIAN"!==j.role&&(console.error("Past Bookings: User is not dietitian",{role:j.role,userId:g.id,timestamp:new Date().toISOString()}),"USER"===j.role?(0,c.redirect)("/user-dashboard"):"ADMIN"===j.role?(0,c.redirect)("/admin"):(0,c.redirect)("/")),"ACTIVE"!==j.account_status&&(console.error("Past Bookings: Account not active",{status:j.account_status,userId:g.id,timestamp:new Date().toISOString()}),(0,c.redirect)("/account-status"));let l=j.id;new Date().toISOString();let{data:m,error:n}=await i.from("bookings").select(`
        id,
        start_time,
        end_time,
        title,
        description,
        meeting_link,
        status,
        event_types:event_type_id (
          id,
          title,
          slug
        ),
        user:users!bookings_user_id_fkey (
          name,
          email
        )
      `).eq("dietitian_id",l).order("start_time",{ascending:!1}),o=m&&!n?m.filter(a=>{let b=new Date(a.start_time)<new Date,c="COMPLETED"===a.status;return b||c}).map(a=>({id:a.id,date:new Date(a.start_time),startTime:new Date(a.start_time),endTime:new Date(a.end_time),title:a.title||a.event_types?.title||"Consultation",eventTypeSlug:a.event_types?.slug||null,description:a.description||"",message:a.description,participants:["You",a.user?.name||a.user?.email||"Client"],meetingLink:a.meeting_link||void 0})):[];return(0,b.jsx)(f.default,{bookings:o,type:"past"})}catch(a){console.error("Past Bookings: Server error",a),(0,c.redirect)("/dietitian-login?redirect=/dashboard/bookings/past")}}a.s(["default",()=>g])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__f4211937._.js.map