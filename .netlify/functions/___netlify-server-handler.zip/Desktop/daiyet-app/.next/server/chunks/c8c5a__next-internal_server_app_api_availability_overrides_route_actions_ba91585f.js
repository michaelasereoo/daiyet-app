module.exports=[21567,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_availability_overrides_route_actions_ba91585f.js.map