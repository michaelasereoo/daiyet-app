module.exports=[14121,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_event-types_%5Bid%5D_route_actions_048e2e53.js.map