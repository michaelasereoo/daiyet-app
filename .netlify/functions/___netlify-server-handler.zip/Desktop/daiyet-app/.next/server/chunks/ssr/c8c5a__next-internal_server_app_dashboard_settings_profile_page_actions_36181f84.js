module.exports=[34605,(a,b,c)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_dashboard_settings_profile_page_actions_36181f84.js.map