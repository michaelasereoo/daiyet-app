module.exports=[67881,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_paystack_webhook_route_actions_2514c53f.js.map