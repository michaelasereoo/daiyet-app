module.exports=[82265,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_signup_page_actions_8c255076.js.map