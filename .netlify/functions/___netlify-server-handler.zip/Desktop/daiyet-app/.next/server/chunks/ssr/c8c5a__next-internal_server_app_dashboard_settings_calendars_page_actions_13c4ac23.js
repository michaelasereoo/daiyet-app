module.exports=[44189,(a,b,c)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_dashboard_settings_calendars_page_actions_13c4ac23.js.map