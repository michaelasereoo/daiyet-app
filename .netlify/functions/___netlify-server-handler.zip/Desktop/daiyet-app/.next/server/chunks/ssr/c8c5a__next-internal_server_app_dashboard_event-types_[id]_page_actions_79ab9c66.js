module.exports=[50052,(a,b,c)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_dashboard_event-types_%5Bid%5D_page_actions_79ab9c66.js.map