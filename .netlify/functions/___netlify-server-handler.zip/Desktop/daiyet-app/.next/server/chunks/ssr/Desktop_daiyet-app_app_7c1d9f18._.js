module.exports=[28591,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},35029,a=>{"use strict";let b={src:a.i(28591).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=Desktop_daiyet-app_app_7c1d9f18._.js.map