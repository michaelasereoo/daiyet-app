module.exports=[3066,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_privacy-policy_page_actions_ef89eab0.js.map