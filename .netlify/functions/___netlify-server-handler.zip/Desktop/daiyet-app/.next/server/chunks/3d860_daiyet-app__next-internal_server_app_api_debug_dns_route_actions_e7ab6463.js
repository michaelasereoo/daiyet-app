module.exports=[57155,(e,o,d)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_api_debug_dns_route_actions_e7ab6463.js.map