module.exports=[94833,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app__global-error_page_actions_03d9f131.js.map