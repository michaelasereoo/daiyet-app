module.exports=[88994,(e,o,d)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_api_bookings_route_actions_87ec0581.js.map