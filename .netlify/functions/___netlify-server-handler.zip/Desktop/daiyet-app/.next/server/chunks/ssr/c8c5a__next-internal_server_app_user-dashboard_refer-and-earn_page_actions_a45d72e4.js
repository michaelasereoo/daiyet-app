module.exports=[40366,(a,b,c)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_user-dashboard_refer-and-earn_page_actions_a45d72e4.js.map