module.exports=[37520,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_admin_bookings_page_actions_c98de0a9.js.map