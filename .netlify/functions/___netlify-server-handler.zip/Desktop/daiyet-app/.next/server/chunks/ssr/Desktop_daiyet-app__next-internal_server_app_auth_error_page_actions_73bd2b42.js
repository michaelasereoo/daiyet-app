module.exports=[68004,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_auth_error_page_actions_73bd2b42.js.map