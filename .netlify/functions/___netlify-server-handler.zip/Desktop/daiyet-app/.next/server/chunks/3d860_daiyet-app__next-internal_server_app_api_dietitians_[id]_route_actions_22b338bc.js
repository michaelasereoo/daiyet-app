module.exports=[3919,(e,o,d)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_api_dietitians_%5Bid%5D_route_actions_22b338bc.js.map