module.exports=[45847,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_admin_analytics_page_actions_22ea4b84.js.map