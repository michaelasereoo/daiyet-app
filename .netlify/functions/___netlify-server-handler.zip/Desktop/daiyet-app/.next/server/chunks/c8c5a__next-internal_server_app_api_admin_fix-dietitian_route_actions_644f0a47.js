module.exports=[85589,(e,o,d)=>{}];

//# sourceMappingURL=c8c5a__next-internal_server_app_api_admin_fix-dietitian_route_actions_644f0a47.js.map