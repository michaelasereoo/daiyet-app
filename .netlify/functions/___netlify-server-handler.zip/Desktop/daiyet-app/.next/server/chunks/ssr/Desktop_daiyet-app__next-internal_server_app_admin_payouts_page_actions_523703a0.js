module.exports=[79565,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_admin_payouts_page_actions_523703a0.js.map