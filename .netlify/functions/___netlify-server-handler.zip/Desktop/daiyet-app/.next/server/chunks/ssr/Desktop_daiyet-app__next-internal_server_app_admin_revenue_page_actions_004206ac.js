module.exports=[37830,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_admin_revenue_page_actions_004206ac.js.map