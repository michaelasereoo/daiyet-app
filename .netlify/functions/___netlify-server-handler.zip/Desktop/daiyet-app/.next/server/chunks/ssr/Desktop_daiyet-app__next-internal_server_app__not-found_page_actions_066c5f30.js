module.exports=[76156,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app__not-found_page_actions_066c5f30.js.map