module.exports=[73564,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_admin_fix-dietitian_page_actions_5b02068d.js.map