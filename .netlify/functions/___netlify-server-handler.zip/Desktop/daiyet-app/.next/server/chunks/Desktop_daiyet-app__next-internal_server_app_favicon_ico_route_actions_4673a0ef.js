module.exports=[19863,(e,o,d)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_favicon_ico_route_actions_4673a0ef.js.map