module.exports=[10883,(e,o,d)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_api_debug_cookies_route_actions_b8193c2b.js.map