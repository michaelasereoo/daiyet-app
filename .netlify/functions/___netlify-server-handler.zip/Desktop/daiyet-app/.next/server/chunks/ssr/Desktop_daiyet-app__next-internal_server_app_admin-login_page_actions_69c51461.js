module.exports=[93759,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_admin-login_page_actions_69c51461.js.map