module.exports=[18287,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_daiyet-app__next-internal_server_app_page_actions_a208493d.js.map