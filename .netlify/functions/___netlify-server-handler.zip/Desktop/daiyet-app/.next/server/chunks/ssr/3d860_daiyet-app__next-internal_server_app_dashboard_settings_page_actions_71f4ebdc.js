module.exports=[41748,(a,b,c)=>{}];

//# sourceMappingURL=3d860_daiyet-app__next-internal_server_app_dashboard_settings_page_actions_71f4ebdc.js.map